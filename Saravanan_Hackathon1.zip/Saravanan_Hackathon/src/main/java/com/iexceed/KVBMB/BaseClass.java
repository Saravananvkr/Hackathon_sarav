package com.iexceed.KVBMB;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import org.junit.jupiter.api.BeforeAll;
import org.openqa.selenium.remote.DesiredCapabilities;
import com.codeborne.selenide.WebDriverRunner;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;

public class BaseClass extends Driversettings implements IAutoConstants {
	@BeforeAll
	public void initTestSuite() throws MalformedURLException {
		WebDriverRunner.setWebDriver(BaseClass.createDriver());
		
	}
	@SuppressWarnings("rawtypes")
	public static AndroidDriver<AndroidElement> createDriver() throws MalformedURLException {
	File f = new File("src");
		File fs = new File(f, "PCloudyHackathon.apk");
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(MobileCapabilityType.DEVICE_NAME, "dcacdad5");
		cap.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");
		cap.setCapability("autoGrantPermissions", "true");
		cap.setCapability("autoAcceptAlerts", "true");
		//cap.setCapability("unicodeKeyboard", "true");
		cap.setCapability("noReset", "true");
		//cap.setCapability("resetKeyboard", "false");
		cap.setCapability(MobileCapabilityType.APP, fs.getAbsolutePath());
		return new AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub"), cap);
	}
}
