package com.iexceed.KVBMB;

import java.net.MalformedURLException;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import com.codeborne.selenide.WebDriverRunner;

@TestInstance(Lifecycle.PER_CLASS)
public class Driversettings extends AppElements{
	@BeforeAll
	public void initTestSuite() throws MalformedURLException {
		WebDriverRunner.setWebDriver(BaseClass.createDriver());
//		Configuration.browser = "chrome";
//		Configuration.startMaximized = true;
//		open("http://10.32.2.101:8586/Aafaq/");
	}
//extends AppElements
}
