package com.iexceed.KVBMB;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class Excel_Data
{

	
	//Method to Read value from Excel
	public static String getValue(String path, String sheet, int r, int c)
	{
		String v="";
		try
		{
			Workbook wb=WorkbookFactory.create(new FileInputStream(path));
			v=wb.getSheet(sheet).getRow(r).getCell(c).toString();
		}
		catch (Exception e) 
		{
			// TODO: handle exception
		}
		return v;
	}
	//Method to Count Number of Row values in excel
	public static int getRowCount(String path, String sheet)
	{
		int rc=0;
		try
		{
			Workbook wb=WorkbookFactory.create(new FileInputStream(path));
			rc=wb.getSheet(sheet).getLastRowNum();
		}
		catch (Exception e) 
		{
			// TODO: handle exception
		}
		return rc;
	}
	//Method to read count of column values
	public static int getColumnCount(String path, String sheet, int r)
	{
		int cc=0;
		try
		{
			Workbook wb=WorkbookFactory.create(new FileInputStream(path));
			cc=wb.getSheet(sheet).getRow(r).getLastCellNum();
		}
		catch (Exception e) 
		{
			// TODO: handle exception
		}
		return cc;
	}
	public void setValue(String path,String flag,String sheet, int c,String x,int totrows)
	{
		try
		{
			InputStream inp = new FileInputStream(path);
			Workbook wb = WorkbookFactory.create(inp);
			Sheet sheet1 = wb.getSheet(sheet);
			int lastrow = sheet1.getLastRowNum();
			System.out.println(lastrow);
			if(flag=="r") {
				lastrow=lastrow+1;
				 Row row=sheet1.createRow(lastrow);
				 String rownum=row.toString();
				 System.out.println(rownum);
			}
		     sheet1.getRow(lastrow).createCell(c).setCellValue(x);
			  FileOutputStream fileOut = new FileOutputStream(path);
				wb.write(fileOut);
				fileOut.close();
		}
		catch (Exception e) 
		{
			// TODO: handle exception
		}
		
	}
	public void createrow(String path, String sheet, int lrow) 
	{
		try {
			System.out.println(path+sheet+lrow);
		InputStream inp = new FileInputStream(path);
		Workbook wb = WorkbookFactory.create(inp);
		Sheet sheet1 = wb.getSheet(sheet);
	     Row row=sheet1.createRow(lrow+1);
	     String rownum=row.toString();
		 System.out.println(rownum);
		  FileOutputStream fileOut = new FileOutputStream(path);
			wb.write(fileOut);
			fileOut.close();
		
	}catch(Exception e) {}
	}	
	public static void writeValue(String path, String sheet, int r, int c,String x)
	{
		try
		{
			InputStream inp = new FileInputStream(path);
			Workbook wb = WorkbookFactory.create(inp);
			Sheet sheet1 = wb.getSheet(sheet);
		     sheet1.getRow(r).createCell(c).setCellValue(x);
			  FileOutputStream fileOut = new FileOutputStream(path);
				wb.write(fileOut);
				fileOut.close();
		}
		catch (Exception e) 
		{
			// TODO: handle exception
		}
		
	}
}
