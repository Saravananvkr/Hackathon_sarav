package com.iexceed.KVBMB;

import org.openqa.selenium.By;

public class AppElements implements IAutoConstants{
	
// Login button element
				
	public By Login_btn1 = By.xpath("//android.widget.Button[@resource-id='com.pcloudyhackathon:id/login']");

	//Double tab button
	
	public By Doubletab = By.xpath("//android.widget.TextView[@resource-id='com.pcloudyhackathon:id/tv_name']");
	
	//Click here button
	
	public By Clickhere = By.xpath("//android.widget.Button[@resource-id='com.pcloudyhackathon:id/click_here']");	
	//com.pcloudyhackathon:id/click_here

	// Success on Double tab
	
	public By Ok_btn = By.xpath("//android.widget.Button[@resource-id='android:id/button1']");
	

// Success assertion
	
	public By Assertion_locator = By.xpath("//android.widget.Button[@resource-id='android:id/message']");
	
	
	

	
	
		// Pay your bills
		
		
		public By Pay_bill_assertion = By.xpath("//android.widget.EditText[@resource-id='CRDPAY__PayCardBills__el_txt_1']");
		public By Minimum_you_can_pay_val = By.xpath("//android.view.View[@resource-id='CRDPAY__PayCardBills__el_txt_15']");
		public By Total_Due_amount_val = By.xpath("//android.view.View[@resource-id='CRDPAY__PayCardBills__dueamount_txtcnt']");
		public By Pay_Amount = By.xpath("//android.widget.EditText[@resource-id='CRDPAY__PayCardBills__PCBamount']");	
		public By Go_head_button = By.xpath("//android.widget.Button[@resource-id='CRDPAY__PayCardBills__el_btn_1']");	
		public By Paybill_Cancel_button = By.xpath("//android.widget.Button[@resource-id='CRDPAY__PayCardBills__el_btn_2']");
		public By OTP_Digit1 = By.xpath("//android.widget.EditText[@resource-id='OTP__OTP__otpno_1']");
		
		public By Numpad_1 = By.xpath("//android.widget.Button[@resource-id='OTP__OTP__el_btn_15']");
		public By Numpad_2 = By.xpath("//android.widget.Button[@resource-id='OTP__OTP__el_btn_16']");
		public By Numpad_3 = By.xpath("//android.widget.Button[@resource-id='OTP__OTP__el_btn_17']");
		public By Numpad_4 = By.xpath("//android.widget.Button[@resource-id='OTP__OTP__el_btn_18']");
		public By Numpad_5 = By.xpath("//android.widget.Button[@resource-id='OTP__OTP__el_btn_19']");
		public By Numpad_6 = By.xpath("//android.widget.Button[@resource-id='OTP__OTP__el_btn_20']");
		public By Numpad_7 = By.xpath("//android.widget.Button[@resource-id='OTP__OTP__el_btn_21']");
		public By Numpad_8 = By.xpath("//android.widget.Button[@resource-id='OTP__OTP__el_btn_22']");
		public By Numpad_9 = By.xpath("//android.widget.Button[@resource-id='OTP__OTP__el_btn_23']");
		public By Numpad_0 = By.xpath("//android.widget.Button[@resource-id='OTP__OTP__el_btn_25']");
		
		public By PB_OTP_Close_button = By.xpath("//android.widget.EditText[@resource-id='AAFAQ__Landing__el_btn_6']");
		public By PB_OTP_Tick_button = By.xpath("//android.widget.EditText[@resource-id='AAFAQ__Landing__el_btn_7']");
		public By PB_OTP_Logout_button = By.xpath("//android.widget.EditText[@resource-id='AAFAQ__Landing__el_btn_8']");
		
		
		
		
		//Transfers main screen
		public By Transfers_Quicktransfer = By.xpath("//android.view.View[@resource-id='section_column_4_li']");
		public By Transfers_ownaccount = By.xpath("//android.view.View[@resource-id='section_column_6_li']");
		public By Transfers_withinKVBaccount = By.xpath("//android.view.View[@resource-id='section_column_8_li']");
		public By Transfers_otherbankaccount = By.xpath("//android.view.View[@resource-id='section_column_10_li']");
		public By Transfers_IMPS_MMID = By.xpath("//android.view.View[@resource-id='section_column_12_li']");
		public By Transfers_TransferUsingUPI = By.xpath("//android.view.View[@resource-id='section_column_14_li']");
		public By Transfers_ManageMMID = By.xpath("//android.view.View[@resource-id='section_column_16_li']");
        //quick transfer
		public By Quick_Transfertype = By.xpath("//android.view.View[@resource-id='transf_type']");
		public By Transfertype_Option1= By.xpath("//android.view.View[@resource-id='option1']");
		public By Transfertype_Option2 = By.xpath("//android.view.View[@resource-id='option3']");
		public By Transfertype_Option3 = By.xpath("//android.view.View[@resource-id='transf_type']");
		//withinbank
		public By QT_payeename = By.xpath("//android.widget.EditText[@resource-id='name']");
		public By QT_payeeaccountno = By.xpath("//android.widget.EditText[@resource-id='to_Acc_Within']");
		public By QT_accountpayeeaccountno = By.xpath("//android.widget.EditText[@resource-id='to_Acc_ConfWithin']");
		public By QT_Transferamount = By.xpath("//android.widget.EditText[@resource-id='amt_Within']");
		public By QT_Remarks = By.xpath("//android.widget.EditText[@resource-id='desc_Within']");
		public By QT_Accounttype = By.xpath("//android.view.View[@resource-id='Benef_o']");
		public By QT_Transferbutton = By.xpath("//android.view.View[@resource-id='quickbtntrn']");
		//->withinbank confirmation screen
		public By QT_confirmbutton = By.xpath("//android.view.View[@resource-id='element_button_24']");
		public By QT_backicon = By.xpath("//android.view.View[@resource-id='section_column_1']");
		public By QT_Homeicon = By.xpath("//android.widget.Image[@resource-id='element_image_1']");
		//->withinbank Authen 
		public By Authentication_Mpin1 = By.xpath("//android.view.View[@resource-id='auth_mpin1_ctrl_div']");
		public By Authentication_Mpin2 = By.xpath("//android.view.View[@resource-id='auth_mpin2_ctrl_div']");
		public By Authentication_Mpin3 = By.xpath("//android.view.View[@resource-id='auth_mpin3_ctrl_div']");
		public By Authentication_Mpin4 = By.xpath("//android.view.View[@resource-id='auth_mpin4_ctrl_div']");
		public By Authentication_OTP1 = By.xpath("//android.view.View[@resource-id='auth_otp1_ctrl_div']");
		public By Authentication_OTP2 = By.xpath("//android.view.View[@resource-id='auth_otp2_ctrl_div']");
		public By Authentication_OTP3 = By.xpath("//android.view.View[@resource-id='auth_otp3_ctrl_div']");
		public By Authentication_OTP4 = By.xpath("//android.view.View[@resource-id='auth_otp4_ctrl_div']");
		public By Authentication_OTP5 = By.xpath("//android.view.View[@resource-id='auth_otp5_ctrl_div']");
		public By Authentication_OTP6 = By.xpath("//android.view.View[@resource-id='auth_otp6_ctrl_div']");
		public By Authentication_OTP7 = By.xpath("//android.view.View[@resource-id='auth_otp7_ctrl_div']");
		public By Authentication_OTP8 = By.xpath("//android.view.View[@resource-id='auth_otp8_ctrl_div']");
		
		public By Authentication_submitbutton = By.xpath("//android.view.View[@resource-id='authSubmitBtn']");
		public By Authentication_backicon	 = By.xpath("//android.widget.Image[@resource-id='auth_header_cross_icon']");

		public By Authentication_keypad1value = By.xpath("//android.view.View[@resource-id='keypad1']");
		public By Authentication_keypad2value = By.xpath("//android.view.View[@resource-id='keypad2']");
		public By Authentication_keypad3value = By.xpath("//android.view.View[@resource-id='keypad3']");
		public By Authentication_keypad4value = By.xpath("//android.view.View[@resource-id='keypad4']");
		//->withinbank success screen 
		
		public By Intoicon  = By.xpath("//android.widget.Image[@resource-id='transtat_icon']");
		public By QT_Successscreen = By.xpath("//android.view.View[@resource-id='section_column_111_sec_col_div']");
		public By QT_NewTrasferbutton= By.xpath("//android.view.View[@resource-id='roww91_ul']");

		
		
		//Otherbank
		public By QT_Payeeifsccode  = By.xpath("//android.view.View[@resource-id='element_button_4']");
		public By QT_ifsccode_bankname = By.xpath("//android.view.View[@resource-id='element_button_4']");
		public By QT_ifsccode_bankname_serach = By.xpath("//android.widget.EditText[@resource-id='QuickBankSearch']");
		public By QT_Payecode_serachvalue_bank  = By.xpath("//android.view.View[@resource-id='BankName__BANK_0']");
 
		public By QT_ifsccode_branchname = By.xpath("//android.widget.EditText[@resource-id='branch1']");
		public By QT_ifsccode_branchname_serach = By.xpath("//android.widget.EditText[@resource-id='QuickBranchSearch']");
		public By QT_Payecode_serachvalue_branch = By.xpath("//android.view.View[@resource-id='BranchName__BRANCH_0']");

		public By QT_chosepayment1  = By.xpath("//android.view.View[@resource-id='paytype1_sec_col_div']");
		public By QT_chosepayment2  = By.xpath("//android.view.View[@resource-id='paytype2_sec_col_div']");
		public By QT_chosepayment3  = By.xpath("//android.view.View[@resource-id='paytype3_sec_col_div']");
		
		
		
		//MMID
		public By QT_PayeeMMID  = By.xpath("//android.widget.EditText[@resource-id='payee_mmid']");
		public By QT_PayeeMobileno  = By.xpath("//android.widget.EditText[@resource-id='payee_mobileno']");
		//public By QT_PayeeMMID  = By.xpath("//android.widget.EditText[@resource-id='payee_mmid']");
		
		//within kvb account
		public By WithinKVB_Transfertype = By.xpath("//android.view.View[@resource-id='transf_type']");
		public By WithinKVB_Addnewpayee = By.xpath("//android.view.View[@resource-id='element_button_3']");
		//public By WithinKVB_Transfertype = By.xpath("//android.view.View[@resource-id='transf_type']");
		public By WithinKVB_Nickname = By.xpath("//android.widget.EditText[@resource-id='NikName_w']");
		public By WithinKVB_name = By.xpath("//android.widget.EditText[@resource-id='Name_w']");
		public By WithinKVB_payeeaccountno = By.xpath("//android.widget.EditText[@resource-id='AccNo_w']");
		public By WithinKVB_confirmpayeeaccountno = By.xpath("//android.widget.EditText[@resource-id='AccNoConf_w']");
		public By WithinKVB_Accountype = By.xpath("//android.view.View[@resource-id='Benef_w']");
		public By WithinKVB_continuebutton = By.xpath("//android.view.View[@resource-id='element_button_6ssssss']");
		 
		//within kvb account->IMPS MMID
		public By IMPSMMID_Nickname = By.xpath("//android.widget.EditText[@resource-id='NikName_m']");
		public By IMPSMMID_name = By.xpath("//android.widget.EditText[@resource-id='Name_m']");
		public By IMPSMMID_payeeMobileno = By.xpath("//android.widget.EditText[@resource-id='MobileNo_m']");
		public By IMPSMMID_PayeeMMID = By.xpath("//android.widget.EditText[@resource-id='AccNoConf_w']");

		//within kvb account->Other bank
		public By Otherbank_Nickname = By.xpath("//android.widget.EditText[@resource-id='NikName_o']");
		public By Otherbank_name = By.xpath("//android.widget.EditText[@resource-id='Name_o']");
		public By Otherbank_payeeaccountno = By.xpath("//android.widget.EditText[@resource-id='AccNo_o']");
		public By Otherbank_confirmpayeeaccountno = By.xpath("//android.widget.EditText[@resource-id='AccNoConf_o']");
		public By Otherbank_Accountype = By.xpath("//android.view.View[@resource-id='Benef_w']");
		public By Otherbank_Ifsccode = By.xpath("//android.widget.EditText[@resource-id='ifscCode']");

}
