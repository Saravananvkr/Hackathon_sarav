package com.iexceed.KVBMB;

import com.iexceed.KVBMB.Excel_Data;

public interface IAutoConstants {
	// File Path
	String EXCEL_PATH = "./Input_Data/Inputs.xlsx";
	String SSPATH = "./Screenshots/";
	
		
	//Login screen
	
	public static final int Login_datacol_num=2;
	
	String Loginpindigit1val = Excel_Data.getValue(EXCEL_PATH, "Login", 1, Login_datacol_num);
	String Loginpindigit2val = Excel_Data.getValue(EXCEL_PATH, "Login", 2, Login_datacol_num);
	String Loginpindigit3val = Excel_Data.getValue(EXCEL_PATH, "Login", 3, Login_datacol_num);
	String Loginpindigit4val = Excel_Data.getValue(EXCEL_PATH, "Login", 4, Login_datacol_num);
	String Loginpindigit5val = Excel_Data.getValue(EXCEL_PATH, "Login", 5, Login_datacol_num);
	String Loginpindigit6val = Excel_Data.getValue(EXCEL_PATH, "Login", 6, Login_datacol_num);
	
	
}
