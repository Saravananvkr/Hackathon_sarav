package com.iexceed.KVBMB.positivecases;

import java.awt.AWTException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;

@TestMethodOrder(OrderAnnotation.class)
public class Login_test extends CommonNavigations {
	
	@Test
	@Tag("Functionality_Positive")
	@DisplayName("Login_Page")
	@Order(1)
	public void Login_Page() throws SecurityException, InterruptedException, AWTException {
		LoginFunctionality1();
	}
	
	
	@Test
	@Tag("Functionality_Positive")
	@DisplayName("Scenario_listTo_Dobletap")
	@Order(2)
	public void Scenario_listTo_Dobletap() throws SecurityException, InterruptedException, AWTException {
		Scenario_listToDobletap();
	}
	
	@Test
	@Tag("Functionality_Positive")
	@DisplayName("Functionality of Double tab")
	@Order(3)
	public void DoubleTabFunctionality() throws SecurityException, InterruptedException, AWTException {
		Double_tab();
	}
	
	@Test
	@Tag("Functionality_Positive")
	@DisplayName("Success pop up")
	@Order(4)
	public void Success_Pop_up() throws SecurityException, InterruptedException, AWTException {
		Success_Popup();
	}
}
