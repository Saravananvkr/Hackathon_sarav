package com.iexceed.KVBMB.positivecases;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

import java.awt.event.KeyEvent;
import java.io.File;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.support.ui.Select;


import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.WebDriverRunner;
import com.iexceed.KVBMB.BaseClass;

import io.appium.java_client.android.AndroidDriver;

public class Commonfunctions extends BaseClass {
	
	
	public void TakeScreenShot(String ClassName, String MethodName, String FileName) throws InterruptedException {
		String dateTime = new Date().toString().replaceAll("[ :]", "_").substring(0, 10);
		String Rpath = SSPATH + ClassName + "/" + MethodName + "_" + dateTime;
		File file = new File(Rpath);
		if (file.exists()) {
			Configuration.reportsFolder = Rpath;
		} else {
			file.mkdir();
			Configuration.reportsFolder = Rpath;
		}
		Thread.sleep(2000);
		Selenide.screenshot(FileName + "_" + new Date().toString().replaceAll("[ :]", "_").substring(0, 16));
	}
	

	// For Android Numbers

	
	

	public void SelectDropDown(String DDID, String Value) {
		Select s = new Select($(By.id(DDID)).waitUntil(visible, 15000));
		s.selectByVisibleText(Value);
	}

	
	// Login function
	
	public void LoginFunctionality1() throws SecurityException, InterruptedException {
		$((Login_btn1)).waitUntil(visible, 5000).click();
		
	}
	
	public void Double_tab() throws SecurityException, InterruptedException {
		
		$((Clickhere)).waitUntil(visible, 5000).doubleClick();
			
	}
	
	public void Success_Popup() throws SecurityException, InterruptedException {
	
	$((Ok_btn)).waitUntil(visible, 5000).click();
	}
	
	
	
	
	
	public void Transfertype(String option) throws SecurityException, InterruptedException {
		 if (option == "1") {
			 this.QuickTransfers_functionality();
		 }
		 else if (option == "2") {
		   this.QuickTransfers_functionality_OB();
		 }
		 else if ( option == "3") {
			 
		 }
		
	}
	
	public void QuickTransfers_functionality() throws SecurityException, InterruptedException {
		Thread.sleep(2000);
		$((Transfers_Quicktransfer)).waitUntil(visible, 30000).click();
		Thread.sleep(2000);
		$((Quick_Transfertype)).waitUntil(visible, 30000).click();
			$((Transfertype_Option1)).waitUntil(visible, 30000).click();	
				$((Transfertype_Option2)).waitUntil(visible, 30000).click();	
		Thread.sleep(2000);
		$((QT_payeename)).waitUntil(visible, 30000).sendKeys("mam");
		Thread.sleep(2000);
		$((QT_payeeaccountno)).waitUntil(visible, 30000).sendKeys("1136177000000183");
		Thread.sleep(2000);
		$((QT_accountpayeeaccountno)).waitUntil(visible, 30000).sendKeys("1136177000000183");
		Thread.sleep(2000);
		$((QT_Transferamount)).waitUntil(visible, 30000).sendKeys("100");
		Thread.sleep(2000);
		$((QT_Remarks)).waitUntil(visible, 30000).sendKeys("vvv");
	}
	public void Quicktransfer_mainscreennavigationclass() throws SecurityException, InterruptedException {
		Thread.sleep(2000);
		$(QT_Transferbutton).waitUntil(visible, 30000).click();
	}
	public void Quicktransfer_Authenticationscreen() throws InterruptedException { 
		Thread.sleep(5000);
		$(Authentication_keypad1value).waitUntil(visible, 30000).click();
		Thread.sleep(2000);
		$(Authentication_keypad2value).waitUntil(visible, 30000).click();
		Thread.sleep(2000);
		$(Authentication_keypad3value).waitUntil(visible, 30000).click();
		Thread.sleep(2000);
		$(Authentication_keypad4value).waitUntil(visible, 30000).click();
		System.out.println("caller");
	}
	public void QuickTransfers_functionality_OB() throws SecurityException, InterruptedException {
		
    $((Transfertype_Option2)).waitUntil(visible, 30000).click();	
	Thread.sleep(2000);
	$((QT_payeename)).waitUntil(visible, 30000).sendKeys("mam");
	Thread.sleep(2000);
	$((QT_payeeaccountno)).waitUntil(visible, 30000).sendKeys("50100312091690");
	Thread.sleep(2000);
	$((QT_accountpayeeaccountno)).waitUntil(visible, 30000).sendKeys("50100312091690");
	Thread.sleep(2000);
	$((QT_Payeeifsccode)).waitUntil(visible, 30000).click();
	$(QT_ifsccode_bankname).waitUntil(visible, 30000).click();
	$(QT_ifsccode_bankname_serach).waitUntil(visible, 30000).sendKeys("HDFC");
	$(QT_Payecode_serachvalue_bank).waitUntil(visible, 30000).click();
//	$().waitUntil(visible, 30000).click();
	$(QT_ifsccode_branchname).waitUntil(visible, 30000).click();
	$(QT_ifsccode_branchname_serach).waitUntil(visible, 30000).sendKeys("GUGAI");
	$(QT_Payecode_serachvalue_branch).waitUntil(visible, 30000).click();
	$((QT_Transferamount)).waitUntil(visible, 30000).sendKeys("100");
	Thread.sleep(2000);
	$((QT_Remarks)).waitUntil(visible, 30000).sendKeys("vvv");
	$((QT_chosepayment1)).waitUntil(visible, 30000).click();
	
	}
}


