package com.iexceed.KVBMB.positivecases;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

import java.awt.AWTException;

import org.openqa.selenium.By;

public class CommonNavigations extends Commonfunctions {
	
	
	public void Login_to_Scenario_list() throws SecurityException, InterruptedException {
		Thread.sleep(2000);
		this.TakeScreenShot("Login_Screen", new Object() {
		}.getClass().getEnclosingMethod().getName(), "Login_Screen");
	
	}
	
	
	public void Scenario_listToDobletap() throws SecurityException, InterruptedException {
		Thread.sleep(2000);
		this.TakeScreenShot("Scenario_List", new Object() {
		}.getClass().getEnclosingMethod().getName(), "Scenario_List");
		$((Doubletab)).waitUntil(visible, 5000).click();
		}
	
	public void QuickkTranfsers_To_confirmation() throws SecurityException, InterruptedException {
		Thread.sleep(10000);
		this.TakeScreenShot("confirmation_Screen", new Object() {
		}.getClass().getEnclosingMethod().getName(), "confirmation_Screen");
// dfds
		$((QT_confirmbutton)).waitUntil(visible, 30000).click();
	}
	public void Quicktransfer_Authenticationnavigtionclass() throws SecurityException, InterruptedException, AWTException {
		Thread.sleep(5000);
		this.TakeScreenShot("Authentication_Screen", new Object() {
		}.getClass().getEnclosingMethod().getName(), "Authentication_Screen");
		$((Authentication_submitbutton)).waitUntil(visible, 30000).click();
		System.out.println("navigate_to_success");
	}
	public void Success() throws SecurityException, InterruptedException, AWTException {
		Thread.sleep(10000);
		this.TakeScreenShot("Success_Screen", new Object() {
		}.getClass().getEnclosingMethod().getName(), "Success_Screen");
		$(QT_NewTrasferbutton).waitUntil(visible, 30000).click();
		System.out.println("success");
	}
}
